import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { Check, Calendar, Sparkles } from "lucide-react";

export interface ProductRecommendation {
  id: string;
  name: string;
  price: string;
  image: string;
  metal: string;
  style: string;
  stone?: string;
  matchReason: string;
}

interface ResultsScreenProps {
  recommendations: ProductRecommendation[];
  onRestart: () => void;
}

export function ResultsScreen({ recommendations, onRestart }: ResultsScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="w-full max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/20 mb-6"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <Sparkles className="w-8 h-8 text-accent" />
          </motion.div>

          <h1
            className="text-4xl md:text-5xl mb-4"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Your Perfect Matches
          </h1>
          <p
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            style={{ fontFamily: 'var(--font-sans)' }}
          >
            Based on your preferences, we've hand-selected these exquisite pieces just for you
          </p>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {recommendations.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
            >
              <div className="group bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-border">
                {/* Product Image */}
                <div className="relative aspect-square overflow-hidden bg-muted">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-accent/90 text-white px-3 py-1 rounded-full text-xs font-medium">
                    Perfect Match
                  </div>
                </div>

                {/* Product Details */}
                <div className="p-6">
                  <h3
                    className="text-xl mb-2"
                    style={{ fontFamily: 'var(--font-serif)' }}
                  >
                    {product.name}
                  </h3>
                  
                  <p
                    className="text-2xl mb-4 text-accent"
                    style={{ fontFamily: 'var(--font-serif)' }}
                  >
                    {product.price}
                  </p>

                  {/* Highlights */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="px-3 py-1 bg-muted rounded-full text-xs" style={{ fontFamily: 'var(--font-sans)' }}>
                      {product.metal}
                    </span>
                    <span className="px-3 py-1 bg-muted rounded-full text-xs" style={{ fontFamily: 'var(--font-sans)' }}>
                      {product.style}
                    </span>
                    {product.stone && (
                      <span className="px-3 py-1 bg-muted rounded-full text-xs" style={{ fontFamily: 'var(--font-sans)' }}>
                        {product.stone}
                      </span>
                    )}
                  </div>

                  {/* Match Reason */}
                  <div className="flex items-start gap-2 mb-6 p-3 bg-accent/5 rounded-lg border border-accent/20">
                    <Check className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-sans)' }}>
                      <span className="font-medium text-foreground">Why this matches you:</span>{' '}
                      {product.matchReason}
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col gap-2">
                    <button
                      className="w-full py-3 px-4 bg-primary text-primary-foreground rounded-xl hover:shadow-lg transition-all hover:scale-105 active:scale-95"
                      style={{ fontFamily: 'var(--font-sans)' }}
                    >
                      View Product
                    </button>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        className="py-2.5 px-4 bg-muted text-foreground rounded-xl hover:bg-secondary transition-colors text-sm"
                        style={{ fontFamily: 'var(--font-sans)' }}
                      >
                        Customize
                      </button>
                      <button
                        className="py-2.5 px-4 bg-muted text-foreground rounded-xl hover:bg-secondary transition-colors text-sm flex items-center justify-center gap-1.5"
                        style={{ fontFamily: 'var(--font-sans)' }}
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        Book Call
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Actions */}
        <motion.div
          className="flex flex-col items-center gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={onRestart}
              className="px-8 py-3 border-2 border-primary text-primary rounded-full hover:bg-primary hover:text-primary-foreground transition-all"
              style={{ fontFamily: 'var(--font-sans)' }}
            >
              Retake Quiz
            </button>
            <button
              className="px-8 py-3 border-2 border-border text-foreground rounded-full hover:border-accent hover:text-accent transition-all"
              style={{ fontFamily: 'var(--font-sans)' }}
            >
              Save Favorites
            </button>
          </div>

          <p className="text-sm text-muted-foreground text-center max-w-xl" style={{ fontFamily: 'var(--font-sans)' }}>
            Need help deciding? Our jewelry consultants are available 24/7 to guide you through your perfect choice.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
