import { motion } from "motion/react";
import { QuizProgressBar } from "@/app/components/quiz-progress-bar";
import { QuizOptionCard } from "@/app/components/quiz-option-card";
import { LucideIcon } from "lucide-react";

export interface QuizOption {
  id: string;
  icon: LucideIcon;
  title: string;
  description?: string;
}

interface QuizScreenProps {
  question: string;
  options: QuizOption[];
  currentStep: number;
  totalSteps: number;
  selectedOption: string | null;
  onSelectOption: (optionId: string) => void;
  onNext: () => void;
  onSkip?: () => void;
  showSkip?: boolean;
}

export function QuizScreen({
  question,
  options,
  currentStep,
  totalSteps,
  selectedOption,
  onSelectOption,
  onNext,
  onSkip,
  showSkip = false,
}: QuizScreenProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Progress Bar */}
      <QuizProgressBar currentStep={currentStep} totalSteps={totalSteps} />

      {/* Content */}
      <motion.div
        className="flex-1 w-full max-w-2xl mx-auto px-6 py-8"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.4 }}
      >
        {/* Question */}
        <motion.h2
          className="text-3xl md:text-4xl mb-12 text-center"
          style={{ fontFamily: 'var(--font-serif)' }}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4 }}
        >
          {question}
        </motion.h2>

        {/* Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {options.map((option, index) => (
            <motion.div
              key={option.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1, duration: 0.4 }}
            >
              <QuizOptionCard
                icon={option.icon}
                title={option.title}
                description={option.description}
                isSelected={selectedOption === option.id}
                onClick={() => onSelectOption(option.id)}
              />
            </motion.div>
          ))}
        </div>

        {/* Action Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.4 }}
        >
          {showSkip && onSkip && (
            <button
              onClick={onSkip}
              className="px-8 py-3 text-muted-foreground hover:text-foreground transition-colors"
              style={{ fontFamily: 'var(--font-sans)' }}
            >
              Skip this question
            </button>
          )}
          <button
            onClick={onNext}
            disabled={!selectedOption}
            className="px-10 py-4 bg-primary text-primary-foreground rounded-full disabled:opacity-40 disabled:cursor-not-allowed hover:shadow-lg transition-all hover:scale-105 active:scale-95"
            style={{ fontFamily: 'var(--font-sans)' }}
          >
            Continue
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
}
