import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface QuizOptionCardProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  isSelected: boolean;
  onClick: () => void;
}

export function QuizOptionCard({
  icon: Icon,
  title,
  description,
  isSelected,
  onClick,
}: QuizOptionCardProps) {
  return (
    <motion.button
      onClick={onClick}
      className={`
        relative w-full p-6 rounded-2xl border-2 transition-all duration-300
        ${isSelected 
          ? 'border-accent bg-accent/5 shadow-lg shadow-accent/10' 
          : 'border-border bg-card hover:border-accent/50 hover:shadow-md'
        }
      `}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex flex-col items-center text-center space-y-3">
        <div className={`
          p-4 rounded-xl transition-colors
          ${isSelected ? 'bg-accent/20' : 'bg-muted'}
        `}>
          <Icon className={`w-6 h-6 ${isSelected ? 'text-accent' : 'text-foreground/60'}`} />
        </div>
        <div>
          <h3 
            className="text-lg font-medium mb-1"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            {title}
          </h3>
          {description && (
            <p 
              className="text-sm text-muted-foreground"
              style={{ fontFamily: 'var(--font-sans)' }}
            >
              {description}
            </p>
          )}
        </div>
      </div>
      {isSelected && (
        <motion.div
          className="absolute top-3 right-3 w-6 h-6 bg-accent rounded-full flex items-center justify-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        >
          <svg
            className="w-4 h-4 text-white"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </motion.div>
      )}
    </motion.button>
  );
}
