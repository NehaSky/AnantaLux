import { motion } from "motion/react";

interface QuizProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function QuizProgressBar({ currentStep, totalSteps }: QuizProgressBarProps) {
  const progress = (currentStep / totalSteps) * 100;

  return (
    <div className="w-full max-w-2xl mx-auto px-6 py-8">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm tracking-wide" style={{ fontFamily: 'var(--font-sans)' }}>
          Step {currentStep} of {totalSteps}
        </span>
        <span className="text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-sans)' }}>
          {Math.round(progress)}%
        </span>
      </div>
      <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-accent"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
