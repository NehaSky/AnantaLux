import { useState } from "react";
import { AnimatePresence } from "motion/react";
import { StartScreen } from "@/app/components/start-screen";
import { QuizScreen, QuizOption } from "@/app/components/quiz-screen";
import { LoadingScreen } from "@/app/components/loading-screen";
import { ResultsScreen, ProductRecommendation } from "@/app/components/results-screen";
import {
  Heart,
  Gift,
  ShoppingBag,
  Sparkles,
  Circle,
  Gem,
  DollarSign,
  Clock,
  Diamond,
  Flower2,
  Star,
  Shield,
} from "lucide-react";

type Screen = "start" | "quiz" | "loading" | "results";

interface QuizAnswers {
  occasion?: string;
  style?: string;
  metal?: string;
  budget?: string;
  stone?: string;
  timeline?: string;
}

const quizQuestions = [
  {
    id: "occasion",
    question: "What's the occasion?",
    showSkip: false,
    options: [
      {
        id: "engagement",
        icon: Heart,
        title: "Engagement",
        description: "A symbol of forever",
      },
      {
        id: "gift",
        icon: Gift,
        title: "Gift",
        description: "Something special for someone",
      },
      {
        id: "self",
        icon: ShoppingBag,
        title: "Self-Purchase",
        description: "Treating yourself",
      },
      {
        id: "milestone",
        icon: Star,
        title: "Milestone",
        description: "Celebrating an achievement",
      },
    ] as QuizOption[],
  },
  {
    id: "style",
    question: "What style speaks to you?",
    showSkip: false,
    options: [
      {
        id: "minimal",
        icon: Circle,
        title: "Minimal",
        description: "Clean and understated",
      },
      {
        id: "classic",
        icon: Shield,
        title: "Classic",
        description: "Timeless elegance",
      },
      {
        id: "bold",
        icon: Sparkles,
        title: "Bold",
        description: "Make a statement",
      },
      {
        id: "luxury",
        icon: Diamond,
        title: "Luxury",
        description: "Opulent and refined",
      },
    ] as QuizOption[],
  },
  {
    id: "metal",
    question: "Which metal do you prefer?",
    showSkip: true,
    options: [
      {
        id: "gold",
        icon: Sparkles,
        title: "Gold",
        description: "Warm and radiant",
      },
      {
        id: "silver",
        icon: Circle,
        title: "Silver",
        description: "Cool and modern",
      },
      {
        id: "platinum",
        icon: Shield,
        title: "Platinum",
        description: "Rare and prestigious",
      },
      {
        id: "no-preference",
        icon: Star,
        title: "No Preference",
        description: "Open to options",
      },
    ] as QuizOption[],
  },
  {
    id: "budget",
    question: "What's your budget range?",
    showSkip: false,
    options: [
      {
        id: "under-1k",
        icon: DollarSign,
        title: "Under $1,000",
      },
      {
        id: "1k-5k",
        icon: DollarSign,
        title: "$1,000 - $5,000",
      },
      {
        id: "5k-10k",
        icon: DollarSign,
        title: "$5,000 - $10,000",
      },
      {
        id: "10k-plus",
        icon: DollarSign,
        title: "$10,000+",
      },
    ] as QuizOption[],
  },
  {
    id: "stone",
    question: "Do you prefer stones?",
    showSkip: true,
    options: [
      {
        id: "diamond",
        icon: Diamond,
        title: "Diamond",
        description: "Forever brilliant",
      },
      {
        id: "gemstone",
        icon: Gem,
        title: "Gemstone",
        description: "Colorful and unique",
      },
      {
        id: "pearl",
        icon: Circle,
        title: "Pearl",
        description: "Classic elegance",
      },
      {
        id: "no-stone",
        icon: Flower2,
        title: "No Stone",
        description: "Metal only",
      },
    ] as QuizOption[],
  },
  {
    id: "timeline",
    question: "When are you looking to purchase?",
    showSkip: false,
    options: [
      {
        id: "immediately",
        icon: Clock,
        title: "Immediately",
        description: "Ready to buy now",
      },
      {
        id: "1-2-weeks",
        icon: Clock,
        title: "1-2 Weeks",
        description: "Soon, but not urgent",
      },
      {
        id: "browsing",
        icon: Clock,
        title: "Just Browsing",
        description: "Exploring options",
      },
    ] as QuizOption[],
  },
];

function App() {
  const [screen, setScreen] = useState<Screen>("start");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswers>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleStart = () => {
    setScreen("quiz");
    setCurrentQuestionIndex(0);
    setAnswers({});
    setSelectedOption(null);
  };

  const handleSelectOption = (optionId: string) => {
    setSelectedOption(optionId);
  };

  const handleNext = () => {
    if (!selectedOption) return;

    // Save answer
    const currentQuestion = quizQuestions[currentQuestionIndex];
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: selectedOption,
    }));

    // Move to next question or finish
    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      // Quiz completed
      setScreen("loading");
      // Simulate processing
      setTimeout(() => {
        setScreen("results");
      }, 2500);
    }
  };

  const handleSkip = () => {
    // Move to next question without saving
    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      setScreen("loading");
      setTimeout(() => {
        setScreen("results");
      }, 2500);
    }
  };

  const handleRestart = () => {
    setScreen("start");
    setCurrentQuestionIndex(0);
    setAnswers({});
    setSelectedOption(null);
  };

  // Generate recommendations based on answers
  const generateRecommendations = (): ProductRecommendation[] => {
    const baseRecommendations: ProductRecommendation[] = [
      {
        id: "1",
        name: "Eternal Solitaire Ring",
        price: "$4,250",
        image: "https://images.unsplash.com/photo-1762505464779-17f78cbfa8b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWFtb25kJTIwcmluZyUyMGVuZ2FnZW1lbnQlMjBlbGVnYW50fGVufDF8fHx8MTc2OTcwNjM1MHww&ixlib=rb-4.1.0&q=80&w=1080",
        metal: "Platinum",
        style: "Classic",
        stone: "Diamond",
        matchReason: "This timeless piece perfectly complements your preference for classic elegance and premium materials.",
      },
      {
        id: "2",
        name: "Grace Pendant Necklace",
        price: "$2,890",
        image: "https://images.unsplash.com/photo-1708221382764-299d9e3ad257?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwbmVja2xhY2UlMjBtaW5pbWFsJTIwbHV4dXJ5fGVufDF8fHx8MTc2OTU5NDYyOHww&ixlib=rb-4.1.0&q=80&w=1080",
        metal: "Gold",
        style: "Minimal",
        stone: "Diamond",
        matchReason: "The refined simplicity and warm gold tone align beautifully with your sophisticated taste.",
      },
      {
        id: "3",
        name: "Elegance Tennis Bracelet",
        price: "$3,450",
        image: "https://images.unsplash.com/photo-1761222101900-9c9e34fac2ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaWx2ZXIlMjBicmFjZWxldCUyMGVsZWdhbnQlMjBqZXdlbHJ5fGVufDF8fHx8MTc2OTU5NzgwN3ww&ixlib=rb-4.1.0&q=80&w=1080",
        metal: "Silver",
        style: "Luxury",
        stone: "Diamond",
        matchReason: "This piece captures luxury and grace, making it ideal for both special occasions and everyday elegance.",
      },
      {
        id: "4",
        name: "Aurora Gemstone Earrings",
        price: "$1,850",
        image: "https://images.unsplash.com/photo-1602751584549-44d0f48236a5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW1zdG9uZSUyMGVhcnJpbmdzJTIwbHV4dXJ5fGVufDF8fHx8MTc2OTcwMjY3NXww&ixlib=rb-4.1.0&q=80&w=1080",
        metal: "Gold",
        style: "Bold",
        stone: "Gemstone",
        matchReason: "These vibrant earrings add a pop of color and personality, perfect for making a statement.",
      },
    ];

    // Filter based on user preferences
    let filtered = [...baseRecommendations];

    // You could add more sophisticated filtering logic based on the answers
    if (answers.metal && answers.metal !== "no-preference") {
      // In a real app, filter by metal type
    }

    if (answers.style) {
      // In a real app, filter by style
    }

    // Return top 3-4 recommendations
    return filtered.slice(0, 4);
  };

  const currentQuestion = quizQuestions[currentQuestionIndex];

  return (
    <div className="min-h-screen" style={{ fontFamily: 'var(--font-sans)' }}>
      <AnimatePresence mode="wait">
        {screen === "start" && (
          <StartScreen key="start" onStart={handleStart} />
        )}

        {screen === "quiz" && currentQuestion && (
          <QuizScreen
            key={`quiz-${currentQuestionIndex}`}
            question={currentQuestion.question}
            options={currentQuestion.options}
            currentStep={currentQuestionIndex + 1}
            totalSteps={quizQuestions.length}
            selectedOption={selectedOption}
            onSelectOption={handleSelectOption}
            onNext={handleNext}
            onSkip={currentQuestion.showSkip ? handleSkip : undefined}
            showSkip={currentQuestion.showSkip}
          />
        )}

        {screen === "loading" && <LoadingScreen key="loading" />}

        {screen === "results" && (
          <ResultsScreen
            key="results"
            recommendations={generateRecommendations()}
            onRestart={handleRestart}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;