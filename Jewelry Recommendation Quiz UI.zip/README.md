
  # Jewelry Recommendation Quiz UI

  This is a code bundle for Jewelry Recommendation Quiz UI. The original project is available at https://www.figma.com/design/BZwerHb9eGAdjKawJ0WhPb/Jewelry-Recommendation-Quiz-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  